<?php 
$host = "Localhost";
$user = "root";
$pass = "";
$DBname = "ukm_fasilkom";

$conn =  mysqli_connect($host, $user, $pass, $DBname);
?>